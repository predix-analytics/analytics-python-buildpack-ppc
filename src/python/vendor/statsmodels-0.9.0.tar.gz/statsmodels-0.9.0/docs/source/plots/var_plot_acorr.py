from var_plots import plot_acorr
plot_acorr()
