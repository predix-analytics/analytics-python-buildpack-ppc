from var_plots import plot_irf
plot_irf()
