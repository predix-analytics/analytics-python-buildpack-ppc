.. _gevent-configuration:

====================
 Configuring gevent
====================

.. seealso:: :func:`gevent.setswitchinterval`
    For additional runtime configuration.

.. autoclass:: gevent._config.Config
