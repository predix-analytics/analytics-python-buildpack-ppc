===============================================================
 :mod:`gevent.subprocess` -- Cooperative ``subprocess`` module
===============================================================

.. automodule:: gevent.subprocess
    :members:
