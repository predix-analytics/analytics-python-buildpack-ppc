======================
 Cooperative Timeouts
======================

Cooperative timeouts can be implemented with the
:class:`gevent.Timeout` class, and the helper function
:func:`gevent.with_timeout`.

.. autoclass:: gevent.Timeout
    :members:
    :undoc-members:
    :special-members: __enter__, __exit__
