======================================================================================================
 :mod:`gevent.backdoor` -- Interactive greenlet-based network console that can be used in any process
======================================================================================================

.. automodule:: gevent.backdoor
    :members:
