================================================================================
 :mod:`gevent.builtins` -- gevent friendly implementations of builtin functions
================================================================================

.. automodule:: gevent.builtins
    :members:
