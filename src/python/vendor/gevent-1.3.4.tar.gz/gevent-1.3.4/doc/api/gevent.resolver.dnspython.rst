===================================================================
 :mod:`gevent.resolver.dnspython` -- Pure Python hostname resolver
===================================================================

.. automodule:: gevent.resolver.dnspython
    :members:
