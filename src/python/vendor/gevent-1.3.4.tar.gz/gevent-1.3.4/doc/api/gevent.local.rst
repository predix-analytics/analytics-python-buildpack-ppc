===============================================
 :mod:`gevent.local` -- Greenlet-local objects
===============================================

.. automodule:: gevent.local
    :members:
