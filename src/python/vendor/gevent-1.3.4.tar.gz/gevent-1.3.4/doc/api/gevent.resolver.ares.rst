===============================================================
 :mod:`gevent.resolver.ares` -- c-ares based hostname resolver
===============================================================

.. automodule:: gevent.resolver.ares
    :members:
