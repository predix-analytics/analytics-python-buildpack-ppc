===============================================================
 :mod:`gevent.monkey` -- Make the standard library cooperative
===============================================================

.. automodule:: gevent.monkey
    :members:
