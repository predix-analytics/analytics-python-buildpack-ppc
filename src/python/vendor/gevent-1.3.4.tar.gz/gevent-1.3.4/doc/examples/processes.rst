=============================
Example processes.py
=============================
.. literalinclude:: ../../examples/processes.py
  :language: python
  :linenos:

`Current source <https://github.com/gevent/gevent/blob/master/examples/processes.py>`_

