=============================
Example echoserver.py
=============================
.. literalinclude:: ../../examples/echoserver.py
  :language: python
  :linenos:

`Current source <https://github.com/gevent/gevent/blob/master/examples/echoserver.py>`_

